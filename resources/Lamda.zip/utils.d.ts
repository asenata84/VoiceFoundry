declare const fs: any;
declare const content = "Some content!";
declare const convertWordToNumber: (word: string) => string;
declare const generateNumberWordsObject: () => void;
declare const generateVanityNumbers: (inputPhone: string) => any;
